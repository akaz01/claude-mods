#!/bin/zsh
set -eu
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
portable_root="${0:A:h}"
print_only=0
if [[ "${1:-}" == "--print-only" ]]; then
  print_only=1
elif [[ $# -gt 0 ]]; then
  print -u2 '사용법: zsh install.command [--print-only]'
  exit 2
fi
if (( ! print_only )) && ! command -v claude >/dev/null 2>&1; then
  print -u2 'Claude Code CLI를 먼저 설치하고 로그인하세요.'
  exit 1
fi
run() {
  if (( print_only )); then
    printf '%q ' "$@"
    printf '\n'
  else
    "$@"
  fi
}
run claude plugin marketplace add "$portable_root/my-mods" --scope user
run claude plugin marketplace add "$portable_root/claude-code-playground/claude-code/mods" --scope user
for plugin in agent-board@my-mods auto-model@my-mods blast-radius@claude-code-playground-mods replay-theater@claude-code-playground-mods token-weather@claude-code-playground-mods; do
  run claude plugin install "$plugin" --scope user
done
if (( ! print_only )); then
  print '설치 완료. 새 Claude Code 세션을 열어주세요.'
  print '자동 모델 선택은 기본 꺼짐입니다. 필요할 때 /auto-model on 으로 켜세요.'
fi
