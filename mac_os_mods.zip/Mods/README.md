# Claude Code Mods — 다른 Mac 설치용

기존 Mods 폴더에서 실행에 필요한 파일만 선별한 패키지입니다. Anthropic/Claude 마크, 현재 모델·브랜치, 나란히 놓은 작은 5h/7d 잔량 바, Codex와 같은 Home·Agents·Log·MCP·Plug·Skills 탭, 고정 헤더·고양이, 다섯 현황 영역과 검정·크림색·흰색 삼색고양이의 7가지 동작을 포함합니다.

하단 context는 Codex와 공통 신호등으로 표시합니다: 초록 Go(<50%), 노랑 Caution(50~74%), 빨강 Stop(75~89%), 빨강 Compact soon(90% 이상). 상단 계정 한도와 별개입니다. agent-board 0.7.0 / token-weather 0.2.0.

## 설치

macOS/zsh와 로그인된 Claude Code CLI가 필요합니다. 검증한 버전은 Claude Code 2.1.296입니다. Mods API를 지원하지 않는 버전에서는 동작하지 않을 수 있습니다. Linux/Windows는 검증하지 않았습니다.

1. ZIP을 풀고 Mods 폴더를 계속 보관할 위치에 둡니다. 예: ~/Developer/tools/Mods.
2. 터미널에서 이 폴더로 이동하여 `zsh install.command`를 실행합니다. Finder에서 install.command를 열어도 됩니다.
3. 새 Claude Code 세션을 엽니다. 열린 세션은 `/reload-plugins`로 다시 불러올 수 있습니다. 대시보드는 `/agent-board`로 열고 닫습니다.

설치 명령만 확인하려면 `zsh install.command --print-only`를 실행하세요. 설치기는 두 로컬 마켓플레이스를 등록하고 아래 다섯 플러그인을 사용자 범위로 설치합니다. 폴더를 이동했다면 마켓플레이스 경로도 다시 등록해야 합니다. 같은 마켓플레이스 이름이 이미 다른 경로로 등록되어 있으면 기존 등록 경로를 먼저 확인하세요.

| 플러그인 | 포함 기능 |
|---|---|
| agent-board@my-mods | 메인 세션·서브에이전트·백그라운드 작업·스킬·MCP 서버 현황, 헤더 테마, 고양이 |
| auto-model@my-mods | 작업별 모델 선택. 세션마다 `/auto-model on`으로 켜며 기본은 꺼짐 |
| blast-radius@claude-code-playground-mods | 변경 영향 표시 |
| replay-theater@claude-code-playground-mods | 작업 기록 재생 표시 |
| token-weather@claude-code-playground-mods | 토큰·컨텍스트 상태 표시 |

자동 모델 선택에 설정된 모델은 새 PC의 계정에서도 사용 가능해야 합니다. 사용 한도는 새 PC에 로그인한 계정의 실제 조회값이며, 제공되지 않는 값은 만들어 표시하지 않습니다. 고양이는 휴식·관찰·작업·분주·확인 대기·오류·완료 상태를 로컬 관측값에 따라 표시합니다.

## 선택 자료와 파일 구성

- my-mods: 직접 만든 대시보드·모델 선택 플러그인의 소스, 선언 파일, 메타데이터.
- claude-code-playground: 세 플러그인과 원본 Apache 2.0 LICENSE만 포함.
- site-handoff: 기획/제작 세션용 CLAUDE.md 템플릿. 설치기가 적용하지 않습니다. 필요할 때 내용을 검토한 후 해당 프로젝트에 직접 복사하세요.
- SHA256SUMS / PACKAGE.json: 포함 파일의 무결성 및 선별 기준.

개인 인증 정보, 전체 Claude 설정, 대화 기록, 프로젝트 소스, 백업, .git, 스크린샷, 테스트 파일과 캐시는 제외했습니다. 실제 고양이 사진도 포함하지 않습니다. 기존 외부 플러그인·MCP 서버·개인 스킬은 이 패키지로 이전되지 않으며 새 PC에서 별도로 구성합니다. Node 의존성 폴더는 필요하지 않습니다. 모드 API는 Claude Code가 제공합니다.

개별 플러그인의 README에는 개발용 테스트 명령이 있을 수 있습니다. 이 실행용 패키지에는 테스트가 포함되지 않습니다. 런타임 파일은 원본 그대로 보존했습니다. Anthropic/Claude 명칭과 마크는 Anthropic의 상표입니다.

파일 확인: 이 폴더에서 `shasum -a 256 -c SHA256SUMS`.
