// Terminal rendering of the official installed Claude app tray mark.
export const CLAUDE_MARK = ["   ⣿⣆ ⢰⡆ ⣀  ", " ⢶⣦⣘⢿⣆⣿⣣⣾⡟⠁ ", "⣀⣀⣈⣛⣿⣿⣿⣿⣯⣤⣤⠦", "⠈⠉⢉⣩⣽⣿⣿⣿⡟⠶⠶⡦", " ⠰⠛⣩⡾⢹⡏⢻⣟⠷⡄ ", "  ⠐⠋ ⢾⠇ ⠙⠁  "]
